# DOM Atomic 02: Hide Many Elements

## Tasks

Write code that accomplishes the following:

1. Find all elements on the page with 'hide_me' as a class.
2. Hide all of those elements when a button is clicked.

There is starter HTML for you.

## Questions

Don't forget to answer the [questions](./QUESTIONS.md).