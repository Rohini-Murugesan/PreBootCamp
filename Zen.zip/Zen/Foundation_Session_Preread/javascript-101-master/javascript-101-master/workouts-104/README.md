# DOM Exercises

These exercises are based on actual tasks web developers use JavaScript for. They all are based on listening for events and modifying the DOM in some way.

For some of the exercises, you'll be given starter HTML and/or JavaScript; but this may not always be the case. The exercises sort-of build in difficulty.

Some of the exercises have an accompanying **QUESTIONS.md** file, which contains one or more questions about the exercise for you to answer.

Begin with the [first exercise now](./01-show-one-element).