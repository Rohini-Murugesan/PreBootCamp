# DOM Atomic 03: Show Many Elements

## Questions

---

> How did you go about hiding elements initially?

Your reply here...