# JavaScript Puzzles

Funny javascript puzzles for those who have some spare time and passion to spend it solving simple but sometimes confusing tasks.

Good luck, hope you enjoy.:-)
