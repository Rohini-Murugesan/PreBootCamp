/*--SUM PAIRS

  Write a method that takes two parameters (array & target value)
  and returns an array of the pairs that sum the target value.

  For example: sumPairs([1, 2, 3, 4, 5], 7) returns [[2, 3], [4, 5]]
*/

var sumPairs;

sumPairs = function(arr, target) {
  return "summon here";
};

/*--Mocha Testing--*/


module.exports = sumPairs;
