/*--IN WORDS

  Write a function that takes a single positive integer 
  and returns its equivalent in words.

  For example: inWords(27) returns "twenty seven"

  The function should work for all numbers ranging
  from zero to the trillions.
*/

var inWords;

inWords = function(num) {
  return "summon here";
};

/*--Mocha Testing--*/


module.exports = inWords;
