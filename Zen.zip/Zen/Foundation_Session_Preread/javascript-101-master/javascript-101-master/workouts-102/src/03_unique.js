/*--UNIQUE

  Write a function that takes an array and returns 
  a new sorted array containing all of the unique elements
  of the original array.

  For example: unique([1, 2, 2, 3]) returns [1, 2, 3];
*/

var unique;

unique = function(arr) {
  return "summon here";
};

/*--Mocha Testing--*/


module.exports = unique;
