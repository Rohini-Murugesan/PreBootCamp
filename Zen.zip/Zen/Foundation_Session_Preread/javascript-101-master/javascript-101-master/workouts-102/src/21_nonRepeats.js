/*--NON REPEATS

  Write a function takes a range of numbers
  and outputs the years that have unique digits.

  For example: nonRepeats(197, 199)) returns [197, 198]
*/

var nonRepeats;

nonRepeats = function(start, end) {
  return "summon here";
};

/*--Mocha Testing--*/


module.exports = nonRepeats;
