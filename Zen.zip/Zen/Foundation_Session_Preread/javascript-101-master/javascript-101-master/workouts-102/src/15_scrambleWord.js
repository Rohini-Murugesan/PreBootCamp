/*--SCRAMBLE WORD

  Write a function that takes two inputs: a word and an array of
  other words. Your program must return all of the words from the array
  that our input word can unscramble to.

  For example: scrambleWord("cat", ["tac", "toc"])) returns ["tac"]
*/

var scrambleWord;

scrambleWord = function(str, arr) {
  return "summon here";
};

/*--Mocha Testing--*/


module.exports = scrambleWord;
