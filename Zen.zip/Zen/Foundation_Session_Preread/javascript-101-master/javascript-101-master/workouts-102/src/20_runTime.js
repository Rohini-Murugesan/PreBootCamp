/*--RUNTIME

  You are given some code in the form of a function. 
  Measure and return the time taken to execute that code.

  For example: runTime(someFunction) returns 17
*/

var runTime;

runTime = function(func) {
  return "summon here";
};

/*--Mocha Testing--*/


module.exports = runTime;
