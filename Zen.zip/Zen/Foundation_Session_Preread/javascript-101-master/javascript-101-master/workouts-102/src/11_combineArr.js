/*--COMBINE ARRAYS

  Write a function that combines two unsorted arrays into a
  sorted array without any duplicates. Use the comparative
  operators for sorting instead of any sorting functions.

  For example: combineArr([2, 4], [1, 3]) returns [1, 2, 3, 4]
*/

var combineArr;

combineArr = function(arr1, arr2) {
  return "summon here";
};

/*--Mocha Testing--*/


module.exports = combineArr;
