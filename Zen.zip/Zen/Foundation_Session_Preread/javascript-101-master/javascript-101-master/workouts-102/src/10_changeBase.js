/*--CHANGE BASE

  Write a method that converts a number from one base to a different base.
  It should work for bases up to 16 (hexadecimal).

  For example: convert 4 from base 10 to base 2, changeBase(4, 10, 2) returns 100

  http://en.wikipedia.org/wiki/Numeral_system
*/

var changeBase;

changeBase = function(num, from, to) {
  return "summon here";
};

/*--Mocha Testing--*/


module.exports = changeBase;
