/*--DIGIT COMBINATIONS

  Write a function that takes a number with distinct digits 
  and returns a sorted array of all the numbers
  than can be formed with those digits.

  For example: digitCombos(123) returns [123, 132, 213, 231, 312, 321]
*/

var digitCombos;

digitCombos = function(num) {
  return "summon here";
};

/*--Mocha Testing--*/


module.exports = digitCombos;
