/*--ORDERED VOWELS

  Write a functions that takes a string of lowercase words and 
  returns a string with just the words containing
  all their vowels in alphabetical order.

  For example: orderedVowels("apple") returns "apple"
*/

var orderedVowels;

orderedVowels = function(str) {
  return "summon here";
};

/*--Mocha Testing--*/


module.exports = orderedVowels;
