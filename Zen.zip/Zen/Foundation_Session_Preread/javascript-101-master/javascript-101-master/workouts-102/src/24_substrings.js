/*--SUBSTRINGS

  Write a function that will take a string 
  and return an array containing each of its substrings. 

  For example: substrings("of") returns ["o", "of", "f"]
*/

var substrings;

substrings = function(str) {
  return "summon here";
};

/*--Mocha Testing--*/


module.exports = substrings;
