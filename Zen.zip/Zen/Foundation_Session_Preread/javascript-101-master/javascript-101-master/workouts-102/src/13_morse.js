/*--MORSE

  Build a function that takes in a string (no numbers or punctuation) 
  and outputs the morse code for it.

  http://en.wikipedia.org/wiki/Morse_code

  Put two spaces between words and one space between letters.

  For example: morse("q") returns "--.-"
*/

var morse;

morse = function(str) {
  return "summon here";
};

/*--Mocha Testing--*/


module.exports = morse;
