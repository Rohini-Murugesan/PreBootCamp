/*--NEAREST LARGER

  Write a function that takes an array and an index.
  The function should return the index of the nearest
  larger integer. In case of a tie, choose the left larger integer
  and return null if no larger numbers are found.

  For example: nearestLarger([1, 4, 3, 2], 2) returns 1
*/

var nearestLarger;

nearestLarger = function(arr, idx) {
  return "summon here";
};

/*--Mocha Testing--*/


module.exports = nearestLarger;
