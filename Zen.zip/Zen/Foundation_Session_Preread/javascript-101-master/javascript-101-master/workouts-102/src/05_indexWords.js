/*--INDEX WORDS

  Write a function that takes an array containing a list of words
  and returns an object mapping out the first letter of each word
  to an array of the words starting with that letter.

  For example: indexWords(["apple", "car", "cat"]) returns {a: ["apple"], c: ["car", "cat"]}
*/

var indexWords;

indexWords = function(arr) {
  return "summon here";
};

/*--Mocha Testing--*/


module.exports = indexWords;
