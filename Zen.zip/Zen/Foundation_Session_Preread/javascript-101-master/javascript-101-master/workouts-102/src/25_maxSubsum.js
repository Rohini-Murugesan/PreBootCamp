/*--MAX SUBSUM

  Write a function that takes an array of integers
  and finds the contiguous subarray within the array with the largest sum.

  http://en.wikipedia.org/wiki/Maximum_subarray_problem 

  For example: maxSubsum([−2, 1, −3, 4, −1, 2, 1, −5, 4]) returns [4, −1, 2, 1]
*/

var maxSubsum;

maxSubsum = function(arr) {
  return "summon here";
};

/*--Mocha Testing--*/


module.exports = maxSubsum;
