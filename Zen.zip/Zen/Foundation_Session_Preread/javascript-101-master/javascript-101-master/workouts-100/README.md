Preread for JSON task:

https://www.youtube.com/watch?v=rJesac0_Ftw
