this has all ppt
