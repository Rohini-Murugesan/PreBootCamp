function first(){
console.log("GUVI Geek Technologies, Chennai");
alert("GUVI Geek Technologies, Chennai");
  };