let countdown = 100;
while (countdown > 1) {
  countdown--;
  if(countdown === 0)
  {
   console.log("bomb triggered");
  }
}