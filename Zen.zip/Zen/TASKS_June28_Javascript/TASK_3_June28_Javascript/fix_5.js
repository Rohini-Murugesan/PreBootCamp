let a = prompt("First number?");
let b = prompt("Second number?");
alert(+a + +b);